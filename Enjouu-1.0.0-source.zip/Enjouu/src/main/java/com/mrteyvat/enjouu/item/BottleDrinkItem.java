package com.mrteyvat.enjouu.item;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.UseAction;
import net.minecraft.world.World;

/** Drinkable item that gives back an empty glass bottle. */
public class BottleDrinkItem extends Item {
    public BottleDrinkItem(Settings settings) {
        super(settings);
    }

    @Override
    public UseAction getUseAction(ItemStack stack) {
        return UseAction.DRINK;
    }

    @Override
    public ItemStack finishUsing(ItemStack stack, World world, LivingEntity user) {
        ItemStack result = super.finishUsing(stack, world, user);
        if (user instanceof PlayerEntity p && p.isCreative()) return result;
        ItemStack bottle = new ItemStack(Items.GLASS_BOTTLE);
        if (result.isEmpty()) return bottle;
        if (user instanceof PlayerEntity p && !p.getInventory().insertStack(bottle)) {
            p.dropItem(bottle, false);
        }
        return result;
    }
}
