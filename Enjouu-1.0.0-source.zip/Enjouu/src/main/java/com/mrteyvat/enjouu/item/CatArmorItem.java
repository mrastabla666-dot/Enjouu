package com.mrteyvat.enjouu.item;

import com.mrteyvat.enjouu.Enjouu;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.CatEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.DyeColor;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;

/**
 * Right-click one of YOUR tamed cats to equip. Gives permanent armor, toughness, +20 health and
 * knockback resistance, and turns the collar gold so you can see which cats are armoured.
 */
public class CatArmorItem extends Item {
    private static final Identifier ARMOR_ID = Enjouu.id("cat_armor_armor");
    private static final Identifier TOUGH_ID = Enjouu.id("cat_armor_toughness");
    private static final Identifier HEALTH_ID = Enjouu.id("cat_armor_health");
    private static final Identifier KB_ID = Enjouu.id("cat_armor_kb");

    public CatArmorItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnEntity(ItemStack stack, PlayerEntity player, LivingEntity entity, Hand hand) {
        if (!(entity instanceof CatEntity cat)) return ActionResult.PASS;
        boolean client = player.getWorld().isClient;
        if (!cat.isTamed() || !cat.isOwner(player)) {
            if (!client) player.sendMessage(Text.translatable("message.enjouu.cat_not_yours"), true);
            return ActionResult.FAIL;
        }
        EntityAttributeInstance armor = cat.getAttributeInstance(EntityAttributes.GENERIC_ARMOR);
        EntityAttributeInstance tough = cat.getAttributeInstance(EntityAttributes.GENERIC_ARMOR_TOUGHNESS);
        EntityAttributeInstance health = cat.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        EntityAttributeInstance kb = cat.getAttributeInstance(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);
        if (armor == null || tough == null || health == null || kb == null) return ActionResult.PASS;
        if (armor.hasModifier(ARMOR_ID)) {
            if (!client) player.sendMessage(Text.translatable("message.enjouu.cat_already_armored"), true);
            return ActionResult.FAIL;
        }
        if (!client) {
            armor.addPersistentModifier(new EntityAttributeModifier(ARMOR_ID, 12.0, EntityAttributeModifier.Operation.ADD_VALUE));
            tough.addPersistentModifier(new EntityAttributeModifier(TOUGH_ID, 4.0, EntityAttributeModifier.Operation.ADD_VALUE));
            health.addPersistentModifier(new EntityAttributeModifier(HEALTH_ID, 20.0, EntityAttributeModifier.Operation.ADD_VALUE));
            kb.addPersistentModifier(new EntityAttributeModifier(KB_ID, 0.5, EntityAttributeModifier.Operation.ADD_VALUE));
            cat.heal(40.0f);
            cat.setCollarColor(DyeColor.YELLOW);
            cat.playSound(SoundEvents.ENTITY_CAT_PURR, 1.0f, 1.0f);
            stack.decrementUnlessCreative(1, player);
            player.sendMessage(Text.translatable("message.enjouu.cat_armored"), true);
        }
        return ActionResult.success(client);
    }
}
