package com.mrteyvat.enjouu.entity;

import com.mrteyvat.enjouu.Chat;
import com.mrteyvat.enjouu.ModItems;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Raihan: always drunk, always smoking, mumbles to anyone nearby, and hates Sahil. */
public class RaihanEntity extends EnjouuBase {
    public RaihanEntity(EntityType<? extends PathAwareEntity> type, World world) {
        super(type, world, "Raihan", Formatting.GOLD);
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(ModItems.DESHI_WINE));
        equipStack(EquipmentSlot.OFFHAND, new ItemStack(ModItems.CIGARETTE));
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0f);
        setEquipmentDropChance(EquipmentSlot.OFFHAND, 0f);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(2, new MeleeAttackGoal(this, 1.0, true));
        goalSelector.add(4, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(5, new LookAtEntityGoal(this, PlayerEntity.class, 8.0f));
        goalSelector.add(6, new LookAroundGoal(this));
        targetSelector.add(1, new RivalTargetGoal<SahilEntity>(this, SahilEntity.class));
    }

    @Override
    protected String[] fightLines() {
        return Chat.RAIHAN_FIGHT;
    }

    @Override
    protected void serverTick() {
        super.serverTick();
        ServerWorld sw = (ServerWorld) getWorld();
        if (age % 6 == 0) {
            Vec3d look = getRotationVec(1.0f);
            sw.spawnParticles(ParticleTypes.SMOKE, getX() + look.x * 0.35, getEyeY() - 0.12, getZ() + look.z * 0.35,
                    1, 0.03, 0.05, 0.03, 0.005);
        }
        // drunk stumble
        if (age % 35 == 0 && random.nextBoolean() && isOnGround()) {
            addVelocity((random.nextDouble() - 0.5) * 0.3, 0.0, (random.nextDouble() - 0.5) * 0.3);
            velocityModified = true;
        }
        // mumble to nearby players
        if (calm <= 0 && getTarget() == null && chatCooldown == 0) {
            if (!sw.getPlayers(p -> p.squaredDistanceTo(this) < 49).isEmpty()) {
                Chat.say(this, npcName, color, Chat.pick(Chat.RAIHAN_DRUNK, random), 7);
                chatCooldown = 100 + random.nextInt(140);
            }
        }
    }
}
