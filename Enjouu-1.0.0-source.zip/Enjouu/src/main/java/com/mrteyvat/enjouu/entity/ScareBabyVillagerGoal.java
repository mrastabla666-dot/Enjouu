package com.mrteyvat.enjouu.entity;

import com.mrteyvat.enjouu.Chat;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;

/** Sahil sneaks up on baby villagers and yells "BOO!" (harmless prank: they just get a shove). */
public class ScareBabyVillagerGoal extends Goal {
    private final SahilEntity mob;
    private VillagerEntity victim;
    private int cooldown;
    private int repath;

    public ScareBabyVillagerGoal(SahilEntity mob) {
        this.mob = mob;
        setControls(EnumSet.of(Control.MOVE, Control.LOOK));
    }

    @Override
    public boolean canStart() {
        if (mob.calm > 0) return false;
        if (cooldown > 0) {
            cooldown--;
            return false;
        }
        List<VillagerEntity> list = mob.getWorld().getEntitiesByClass(VillagerEntity.class,
                mob.getBoundingBox().expand(12, 4, 12), v -> v.isAlive() && v.isBaby());
        if (list.isEmpty()) {
            cooldown = 60;
            return false;
        }
        list.sort(Comparator.comparingDouble(v -> v.squaredDistanceTo(mob)));
        victim = list.get(0);
        return true;
    }

    @Override
    public boolean shouldContinue() {
        return victim != null && victim.isAlive() && mob.calm <= 0 && mob.getTarget() == null
                && mob.squaredDistanceTo(victim) < 300;
    }

    @Override
    public void stop() {
        victim = null;
        cooldown = 160;
        mob.getNavigation().stop();
    }

    @Override
    public void tick() {
        if (victim == null) return;
        mob.getLookControl().lookAt(victim, 30.0f, 30.0f);
        if (mob.squaredDistanceTo(victim) > 6.0) {
            if (--repath <= 0) {
                repath = 8;
                mob.getNavigation().startMovingTo(victim, 1.25);
            }
            return;
        }
        Vec3d away = victim.getPos().subtract(mob.getPos()).normalize();
        victim.addVelocity(away.x * 0.7, 0.45, away.z * 0.7);
        victim.velocityModified = true;
        victim.playSound(SoundEvents.ENTITY_VILLAGER_NO, 1.0f, 1.8f);
        mob.swingHand(Hand.MAIN_HAND);
        ((ServerWorld) mob.getWorld()).spawnParticles(ParticleTypes.ANGRY_VILLAGER, victim.getX(), victim.getEyeY() + 0.4,
                victim.getZ(), 4, 0.25, 0.2, 0.25, 0.0);
        Chat.say(mob, "Sahil", Formatting.AQUA, Chat.pick(Chat.SAHIL_SCARE, mob.getRandom()), 16);
        victim = null;
    }
}
